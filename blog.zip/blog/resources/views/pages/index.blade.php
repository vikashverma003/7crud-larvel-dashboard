@extends('layouts.app')

@section('content')

        <div class="jumbotron text-center">

        <h1>This is our index page</h1>
        <p>And welcome to laravel from scratch </p>


    </div>
       
    @endsection