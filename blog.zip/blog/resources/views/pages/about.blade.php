@extends('layouts.app')

@section('content')


        <h1>This is our about page</h1>
        <p>And welcome to laravel from scratch </p>

@endsection    