<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Mail;

class PagesController extends Controller
{



    public function sendMail(Request $request)
    {

        Mail::send(['text'=>'mail'],['name', 'vikas'], function($message){

            $message->to('vikashverma003@gmail.com', 'to vikash')->subject('test mail');
            $message->from('vikashverma003@gmail.com', 'vikash');


        });    





    }
    
    public function index()

    {


    	return view('pages.index');
    }

     public function about()

    {


    	return view('pages.about');
    }


     public function services()

    {

    	$data = array(

    		'services'=>'here is services',

    		'title'=> ['weq', 'ere', 'dfdf']


    		);

    	return view('pages.services')->with($data);
    }
}
