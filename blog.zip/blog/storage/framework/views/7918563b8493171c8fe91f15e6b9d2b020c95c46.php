<?php $__env->startSection('content'); ?>


        <h1>This is our about page</h1>
        <p>And welcome to laravel from scratch </p>

<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>