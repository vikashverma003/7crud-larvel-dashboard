<?php $__env->startSection('content'); ?>


        <h1>This is our Services page</h1>
        <p>And welcome to laravel from scratch </p>

        <h2><?php echo e($services); ?></h2>

        <?php if(count($title)>0): ?>

        <ul class="list-group">
        <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="list-group-item"><?php echo e($titles); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

        <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>