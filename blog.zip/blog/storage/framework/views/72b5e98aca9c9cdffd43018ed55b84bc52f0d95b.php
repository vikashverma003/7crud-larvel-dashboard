<?php $__env->startSection('content'); ?>

        <div class="jumbotron text-center">

        <h1>This is our index page</h1>
        <p>And welcome to laravel from scratch </p>


    </div>
       
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>